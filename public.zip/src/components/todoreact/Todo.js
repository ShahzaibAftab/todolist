import './Todo.css'
import React, { useEffect, useState } from 'react'
import {AiOutlinePlus} from 'react-icons/ai'
import {AiOutlineDelete} from 'react-icons/ai'
import img from "./Images/notebook.png"
// For local data read/write
const getLocalData=()=>{
  const lists=localStorage.getItem("mytodolist");
  if(lists)//there is data
  {
    return JSON.parse(lists);
  }
  else
  {
    return[];
  }
}
const Todo = () => {
  const [inputData,setInputData]=useState("");
  const [items,setItems]=useState(getLocalData());
  const [isEditItem,setIsEditItem]=useState("");
  const [toggleButton,setToggleButton]=useState(false);
  const addItem=()=>
  {
    if(!inputData)//Empty Input Data
    {
      alert('Please fill the form');
    }
    else if(inputData && toggleButton)
    {
      setItems(items.map((curElem)=>{
        if(curElem.id===isEditItem)
        {
          return {...curElem,name:inputData};
        }
        return curElem;
      }))
      setInputData([]);
      setIsEditItem(null);
      setToggleButton(false);
    }
    else
    {
      const myNewInputData = {
        id: new Date().getTime().toString(),
        name: inputData,
       };
      setItems([...items,myNewInputData])///spread operator means, is se previous state me jo data tha wo store kr k rakho
      setInputData("");///blank after adding note
    }
  };
  //edit section
  const editItem=(index)=>
  {
    const item_todo_edited=items.find((curElem)=>
    {
      return curElem.id===index;
    });
    setInputData(item_todo_edited.name);
    setIsEditItem(index);
    setToggleButton(true);
  };
  // Delete items
  const deleteItem=(index)=>{
    const updatedItem=items.filter((curElem)=>{
      return curElem.id!==index;
    })
    setItems(updatedItem)
  };
  const removeAll=()=>
  {
    setItems([]);
  }
  ///////need useeffect because we are automating
  useEffect(()=>
  {
    localStorage.setItem("mytodolist",JSON.stringify(items))//items is Array of object, JSON.stingify is type casting array into string
  },[items]);
  return (
    <div className='mainDiv'>
        <div className='childDiv'>
          <p>Notepad using local storage Visit Github for code</p>
            <figure>
                <img src={img} alt='icon'/>
                <figcaption>Add Your list here ✌ </figcaption>
            </figure>
            <div className='addItems'>
              <input type='text' value={inputData} onChange={(event)=>setInputData(event.target.value)} placeholder='Add Item😉 ' className='formControl'/>
               {/* <AiOutlinePlus onClick={()=>addItem()} className='icon'/> */}
               {toggleButton ?(<AiOutlineDelete onClick={()=>addItem()} className='icon'/>
               ) :(<AiOutlinePlus onClick={()=>addItem()} className='icon'/> )}
            </div>
            {/* Added will show here */}
            <div className='showItems'>

             { items.map((curElem,index)=>{
              return(
                <div className='eachItem' key={index}>
                <h3>{curElem.name}</h3>
                <div className='todoBtn'>
                <AiOutlinePlus className='icon' onClick={()=>{editItem(curElem.id)}}/>
                <AiOutlineDelete className='icon' onClick={()=> {deleteItem(curElem.id)}}/>
                </div>
              </div>  
              )
             })}
              
            </div>
            <div className='showItems'> <button className='submitBtn' onClick={()=>removeAll()}>Delete All</button>
             </div>
        </div>
    </div>
  )
}

export default Todo