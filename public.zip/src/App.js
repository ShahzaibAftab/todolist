import './App.css';
import Todo from './components/todoreact/Todo';
function App() {
  return (
   <>
   <Todo/>
   </>
  );
}

export default App;
